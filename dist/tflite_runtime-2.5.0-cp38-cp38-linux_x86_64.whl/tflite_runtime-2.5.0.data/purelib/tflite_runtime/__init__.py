__version__ = '2.5.0'
__git_version__ = '0.6.0-107939-ga4dfb8d1a71'
